-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 20 déc. 2022 à 17:14
-- Version du serveur : 10.4.19-MariaDB
-- Version de PHP : 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `aeek_exam`
--

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

CREATE TABLE `question` (
  `id_question` int(111) NOT NULL,
  `date_question` datetime DEFAULT NULL,
  `quiz_id` int(11) DEFAULT NULL,
  `type_question` int(11) DEFAULT 0,
  `question` varchar(225) DEFAULT NULL,
  `point` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `question`
--

INSERT INTO `question` (`id_question`, `date_question`, `quiz_id`, `type_question`, `question`, `point`) VALUES
(1, '2022-12-20 14:46:57', 2, 0, 'Que signifie AEEK ?', 5),
(2, '2022-12-20 14:46:57', 2, 0, 'Qui est le président de l\'AEEK ?', 5),
(3, '2022-12-20 14:46:57', 2, 0, 'Qui est le secrétaire général de l\'AEEK ?', 5),
(4, '2022-12-20 14:46:57', 2, 0, ' Qui est Yafe de l\'AEEK ?', 5);

-- --------------------------------------------------------

--
-- Structure de la table `question_opt`
--

CREATE TABLE `question_opt` (
  `id_question_opt` int(111) NOT NULL,
  `question_id` int(111) DEFAULT NULL,
  `option` varchar(225) DEFAULT NULL,
  `opt_point` float NOT NULL DEFAULT 0,
  `is_right` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `question_opt`
--

INSERT INTO `question_opt` (`id_question_opt`, `question_id`, `option`, `opt_point`, `is_right`) VALUES
(1, 1, 'Association es mangeurs', 0, 0),
(2, 1, 'Association es entreprise', 0, 0),
(3, 1, 'Association des élèves et étudiants de Kassséré', 5, 1),
(4, 2, 'Dramane', 0, 0),
(5, 2, 'Gnelezie', 5, 1),
(6, 2, 'Yahafe', 0, 0),
(7, 3, 'Kone Zana', 0, 0),
(8, 3, 'Sangare Beh', 0, 0),
(9, 3, 'Ouattara Beh Brahima', 5, 1),
(10, 4, 'Membre', 0, 0),
(11, 4, 'Organusateur', 5, 1),
(12, 4, 'Professeurs', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `quiz`
--

CREATE TABLE `quiz` (
  `id_quiz` int(11) NOT NULL,
  `date_quiz` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `title` varchar(225) DEFAULT NULL,
  `description` varchar(225) DEFAULT NULL,
  `duree` int(11) DEFAULT NULL,
  `couverture` varchar(225) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `quiz`
--

INSERT INTO `quiz` (`id_quiz`, `date_quiz`, `user_id`, `slug`, `title`, `description`, `duree`, `couverture`, `statut`) VALUES
(1, '2022-12-20 13:53:31', 1, 'etre-au-present', 'Être au présent', 'Conjugez le verbe être a toute les personnes', 10, 'couv.jpg', 0),
(2, '2022-12-20 14:04:22', 1, 'connaitre-aeek', 'Connaître AEEK', 'Un questionnaire pour miex comprendre connaitre l\'AEEK', 15, 'logoAEEK.png', 0);

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

CREATE TABLE `reponse` (
  `id_reponse` int(111) NOT NULL,
  `date_reponse` datetime DEFAULT NULL,
  `users_id` int(111) DEFAULT NULL,
  `quiz_id` int(111) DEFAULT NULL,
  `opt_id` int(111) DEFAULT NULL,
  `is_right` int(111) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id_question`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Index pour la table `question_opt`
--
ALTER TABLE `question_opt`
  ADD PRIMARY KEY (`id_question_opt`),
  ADD KEY `question_id` (`question_id`);

--
-- Index pour la table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`id_quiz`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `slug` (`slug`);

--
-- Index pour la table `reponse`
--
ALTER TABLE `reponse`
  ADD PRIMARY KEY (`id_reponse`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `quiz_id` (`quiz_id`),
  ADD KEY `opt_id` (`opt_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `question`
--
ALTER TABLE `question`
  MODIFY `id_question` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `question_opt`
--
ALTER TABLE `question_opt`
  MODIFY `id_question_opt` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `id_quiz` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `reponse`
--
ALTER TABLE `reponse`
  MODIFY `id_reponse` int(111) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id_quiz`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `question_opt`
--
ALTER TABLE `question_opt`
  ADD CONSTRAINT `question_opt_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `question` (`id_question`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
